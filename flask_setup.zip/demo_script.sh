sh setup_script.sh
sh run_script.sh